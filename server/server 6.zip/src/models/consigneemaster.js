



const mongoose = require("mongoose");

const ConsigneeSchema = new mongoose.Schema({
    name: { type: String, required: true },
    place: { type: String, required: true },
    district: { type: String ,required: true },
    mobileNo: { type: Number },
    group_id: { type: String, trim: true },
}, { timestamps: true });

module.exports = mongoose.model("consigneemaster", ConsigneeSchema);
