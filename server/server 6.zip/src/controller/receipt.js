const express = require("express");
const receipt = require("../models/receipt");



exports.submit_form = async (req, res) => {
    try {
        const date = new Date();
        const formattedDate = date.toISOString().split("T")[0].replace(/-/g, ""); // YYYYMMDD

        const {
            vendor_name,
            address,
            supplier_name,
            mobileNo,
            ship_to_address1,
            ship_to_district,
            transport_mode,
            transport_number,
            transport_driver_name,
            productDetails, // Already an array from frontend
            total_freight,
            advance_paid,
            to_pay,
            sc,
            hamali,
            sch,
            total,
            from,
            group_id,
            receiver
        } = req.body;

        console.log("sc", sc);
        
        const parsed_productdetails = productDetails && JSON.parse(productDetails)

        // ✅ Extract First Letters of Each Word from group_id
        const groupPrefix = group_id
            .split(" ")
            .map(word => word[0])
            .join("")
            .toUpperCase(); // Example: "Kisan Seeds Corporation" → "KSC"

        // ✅ Check if Receipt Already Exists for Vendor in Group
        const existingReceipt = await receipt.findOne({
            vendor_name: vendor_name?.trim(),
            group_id: group_id?.trim(),
        });

        if (existingReceipt) {
            return res.status(400).json({
                message: "Receipt with this name already exists in this group",
            });
        }

        // ✅ Find Last Receipt for the Group Using Dynamic Prefix
        const lastReceipt = await receipt.findOne({
            receipt_number: new RegExp(`^${groupPrefix}-${formattedDate}-`, "i"),
        })
            .sort({ tran_date: -1 }) // Sort by latest transaction date
            .exec();

        let nextCounter = 1;
        if (lastReceipt) {
            const lastNumber = parseInt(lastReceipt.receipt_number.split("-").pop(), 10);
            nextCounter = lastNumber + 1;
        }

        // ✅ Generate New Receipt Number
        const receiptNo = `${groupPrefix}-${formattedDate}-${nextCounter}`;

        // ✅ Create a New Receipt Document
        const newReceipt = new receipt({
            tran_date: new Date(),
            receipt_number: receiptNo,
            vendor_name: vendor_name.trim(),
            address: address.trim(),
            from: from ? from.trim() : "",
            productDetails: parsed_productdetails, // Directly use without JSON.parse
            ship_to_address1: ship_to_address1 ? ship_to_address1.trim() : "",
            ship_to_district: ship_to_district ? ship_to_district.trim() : "",
            transport_mode: transport_mode ? transport_mode.trim() : "",
            supplier_name: supplier_name ? supplier_name.trim() : "",
            mobileNo:mobileNo,
            transport_number: transport_number ? transport_number.trim() : "",
            transport_driver_name: transport_driver_name ? transport_driver_name.trim() : "",
            total_freight: total_freight || 0,
            advance_paid: advance_paid || 0,
            to_pay: to_pay || 0,
            sc: sc && sc,
            hamali: hamali || 0,
            sch: sch || 0,
            total: total || 0,
            group_id: group_id?.trim(),
            receiver: receiver ? receiver.trim() : "",
        });

        const savedReceipt = await newReceipt.save();

        return res.status(201).json({
            data: savedReceipt,
            status: "success",
            message: "Receipt Saved Successfully",
        });
    } catch (error) {
        console.error("Error saving receipt:", error.message);
        return res.status(500).json({
            status: "error",
            message: "Something went wrong while saving the receipt",
        });
    }
};


exports.getallusers = async (req, res) => {
    // console.log(req.params);
    try {
        const allusers = await receipt.find({ group_id: req.params.id }).sort({ createdAt: -1 })
        // console.log(allusers);

        return res.status(201).json({
            data: allusers,
            status: "success",
            message: "candidate get successfully",
            count: allusers.length
        })
    }
    catch (err) {
        console.log(err.message)
    }
}


exports.getsingleusers = async (req, res) => {
    // console.log(req.params);
    try {
        const singleusers = await receipt.findById(req.params.id)
        //  console.log(singleusers);
        return res.status(201).json({
            data: singleusers,
            status: "success",
            message: "candidate get successfully"
        })
    }
    catch (err) {
        console.log(err.message)
    }
}


exports.getallinfo = async (req, res) => {
    // console.log(req.params);
    try {
        const allinfo = await receipt.find()
        // console.log(allinfo);
        return res.status(201).json({
            allinfo
            // status:"success",
            // message:"candidate get successfully",
            // count: allusers.length
        })
    }
    catch (err) {
        console.log(err.message)
    }
}



exports.getallreceipts = async (req, res) => {
    try {
        const { filterType, groupId } = req.params; // Get filterType & groupId from request
        // console.log("filterType", filterType);
        // console.log("groupId", groupId);

        if (!filterType || !groupId) {
            return res.status(400).json({ error: "Filter Type and Group ID are required!" });
        }

        let groupFormat;
        if (filterType === "today") {
            groupFormat = { $dateToString: { format: "%Y-%m-%d", date: "$tran_date" } }; // Group by Date (YYYY-MM-DD)
        } else if (filterType === "week") {
            groupFormat = { $isoWeek: "$tran_date" }; // Group by Week Number
        } else if (filterType === "month") {
            groupFormat = { $dateToString: { format: "%Y-%m", date: "$tran_date" } }; // Group by Month (YYYY-MM)
        } else if (filterType === "year") {
            groupFormat = { $year: "$tran_date" }; // Group by Year
        } else {
            return res.status(400).json({ error: "Invalid filter type!" });
        }

        // 📌 MongoDB Aggregation Query
        const result = await receipt.aggregate([
            { $match: { group_id: groupId } }, // 🔍 Match group ID
            {
                $group: {
                    _id: groupFormat,
                    count: { $sum: 1 },
                },
            },
            { $sort: { _id: 1 } }, // 📅 Sort by date
        ]);

        // 📌 Format Data for Chart
        const formattedData = result.map((item) => ({
            label: item._id.toString(), // X-Axis (Date, Week, Month, Year)
            value: item.count, // Y-Axis (Receipt Count)
        }));
        // console.log("formattedData",formattedData);

        res.json({ filterType, groupId, data: formattedData });
    } catch (error) {
        console.error("Error fetching LR receipt count:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};




exports.regenerateReceipt = async (req, res) => {
    try {
        const { receipt_id } = req.body;

        if (!receipt_id) {
            return res.status(400).json({ error: "Receipt ID is required!" });
        }

        // ✅ Step 1: Find the existing receipt
        const existingReceipt = await receipt.findById(receipt_id);

        if (!existingReceipt) {
            return res.status(404).json({ error: "Receipt not found!" });
        }

        // ✅ Step 2: Extract required parts
        const groupPrefix = existingReceipt.group_id
            .split(" ") // Split by spaces
            .map(word => word[0]) // Take the first letter of each word
            .join("") // Join letters together
            .toUpperCase(); // Convert to uppercase

        const fullReceiptId = existingReceipt._id.toString(); // Full MongoDB Object ID
        const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, ""); // YYYYMMDD

        // ✅ Step 3: Extract last index & increment it
        const lastIndex = parseInt(existingReceipt.receipt_number.split("-").pop()) || 0;
        const newIndex = lastIndex + 1;

        // ✅ Step 4: Generate new receipt number
        const newReceiptNumber = `${groupPrefix}-${datePart}-${newIndex}`;

        // ✅ Step 5: Create a new receipt entry with the updated number
        const newReceipt = new receipt({
            ...existingReceipt.toObject(),
            _id: undefined, // Remove old ID so MongoDB assigns a new one
            receipt_number: newReceiptNumber,
            createdAt: new Date(), // Update creation time
        });

        await newReceipt.save();

        res.status(201).json({
            message: "Receipt regenerated successfully",
            newReceiptNumber,
            newReceipt
        });

    } catch (error) {
        console.error("Error regenerating receipt:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};



exports.updateReceipt = async (req, res) => {
 

    try {
        const { id } = req.params;
        const updatedData = req.body;

        const updatedReceipt = await receipt.findByIdAndUpdate(id, updatedData, { new: true });

        if (!updatedReceipt) {
            return res.status(404).json({ error: "Receipt not found!" });
        }

        res.status(200).json({ message: "Receipt updated successfully", updatedReceipt });
    } catch (error) {
        console.error("Error updating receipt:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

