import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Homepage.css";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { userLogout } from "./Redux/actions";
// import * as React from 'react';
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
// import { Button } from "antd";
import { Button, Card, Typography, Row, Col } from "antd";
const { Title, Paragraph } = Typography;

function App(props) {
  const [selectedOption, setSelectedOption] = useState("");
  const navigate = useNavigate();

  const handleOptionChange = (event) => {
    const selectedRoute = event.target.value;
    setSelectedOption(selectedRoute);

    if (selectedRoute) {
      navigate(selectedRoute); // Navigate to the selected route
    }
  };

  useEffect(() => {
    props.userLogout();
  }, []);

  return (


    <div className="outer">




      <div class="containers">








      </div>
      <div class="image-overlay">

        {/* </div> */}
        <div class="login-options">
          {/* <div class="design">

            <h2 style={{ alignContent: 'center', textAlign: 'center', color: 'black' }}>Choose Login Option </h2>
            <div class="buttons">
              <Button class="organisation" onClick={() => navigate("/adminlogin")} style={{ width: "200px", height: "50px" }}>Company Admin</Button>
              <Button class="member" onClick={() => navigate("/userlogin")} style={{ width: "200px", height: "50px" }}>Employee</Button>
            </div>
          </div> */}
          <Title level={2} style={styles.title}>
          Bharat Freight Solutions
          </Title>
          <Paragraph style={styles.paragraph}>
            Efficiently manage your fleet with our advanced system.
          </Paragraph>

          <Title level={3} style={styles.subtitle}>
            Choose Login Option
          </Title>

          <Row justify="center" gutter={16} style={{ marginTop: "20px" }}>
            <Col>
              <Button type="primary" size="large" onClick={() => navigate("/adminlogin")}>
                Company Admin
              </Button>
            </Col>
            <Col>
              <Button type="default" size="large" onClick={() => navigate("/userlogin")}>
                Employee
              </Button>
            </Col>
          </Row>
          <Paragraph style={styles.paragraphh}>

            For more information or query contact  <a href="http://www.bharat-online.com" target="_blank">
              www.bharat-online.com</a>
          </Paragraph>

        </div>
      </div>


    </div>

  );
}
const styles = {
  outer: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  row: {
    width: "80%",
    maxWidth: "1100px",
  },
  imageContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  lorryImage: {
    width: "100%",
    maxWidth: "400px",
    borderRadius: "10px",
  },
  card: {
    textAlign: "center",
    padding: "30px",
    borderRadius: "10px",
    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.3)",
  },
  title: {
    color: "#AA2B1D",
    textAlign: "center",
    marginBottom: "10px",
    marginTop: "200px",
    fontSize: "60px"
  },
  paragraph: {
    textAlign: "center",
    marginBottom: "20px",
    fontSize:"20px"
  },

  paragraphh: {
    textAlign: "center",
    marginBottom: "20px",
    fontSize:"17px",
    marginTop:"280px"
  },
  subtitle: {
    textAlign: "center",
    color: "black",
    marginTop: "60px"
  },
};
const mapStateToProps = (state) => {
  return { candidate: state.candidate };
};

const mapDispatchToProps = (dispatch) =>
  bindActionCreators({ userLogout }, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(App);

