import React, { useEffect, useState } from "react";
import {
    Button,
    Modal,
    Form,
    Input,
    Table,
    Typography,
    Space,
    Card,
    Upload,
    Popconfirm,
    message
} from "antd";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { PlusOutlined, UploadOutlined } from "@ant-design/icons";
import Papa from "papaparse";
import axios from "axios";
import { useNavigate, useParams } from 'react-router-dom';

const BASEURL = "/api"

const ConsigneeMaster = () => {
    const navigate = useNavigate();
    const { groupId } = useParams()
    console.log(groupId);
    const [open, setOpen] = useState(false);
    const [bulkUploadOpen, setBulkUploadOpen] = useState(false);
    const [fileList, setFileList] = useState([]);
    // const [consigneeList, setConsignees] = useState([]);

    const [products, setConsignees] = useState([]);
    console.log(products);
    const [currentConsignee, setCurrentConsignee] = useState(null); // Stores Selected Consignee for Editing
    const [editOpen, setEditOpen] = useState(false); // Controls Edit Modal State
    const [value, setValue] = useState({})
    console.log(value.id);
    const [editForm] = Form.useForm(); // Antd Form Hook
    const [form] = Form.useForm(); // Antd Form Hook
    const userId = value.id

    const handleOpen = () => {
        form.resetFields();
        setOpen(true);
    };

    useEffect(() => {
        const savedInfo = localStorage.getItem("info");
        if (savedInfo) {
            const parsedInfo = JSON.parse(savedInfo);
            setValue(parsedInfo);
        }
        else {
            navigate("/");
        }

    }, []);

    const handleEditOpen = (product) => {
        //console.log("Editing Consignee:", product);
        setCurrentConsignee(product);
        editForm.setFieldsValue(product); // Pre-fill form with selected product details
        setEditOpen(true);
    };

    const handleClose = () => setOpen(false);
    // Add Consignee
    const addConsignee = () => {
        form.validateFields().then(async (values) => {
            console.log("values", values);
            console.log("User ID:", value.id);
            const payload = { ...values, groupId };
            try {
                const response = await axios.post(`${BASEURL}/consigneemaster`, payload);
                // setConsignees([...products, response.data.product]); // Update UI
                fetchConsignees();
                message.success({
                    content: response.data.message,
                    duration: 2, // Time before it disappears (in seconds)
                    style: {
                        marginTop: "25vh", // Moves it to center vertically
                        textAlign: "center", // Ensures text is centered
                        // Moves it to center horizontally
                    }
                });
                handleClose();
            } catch (error) {
                console.error("Error adding product:", error);
                alert("Failed to add product!");
            }
        });
    };


    const fetchConsignees = async () => {
        try {
            const response = await axios.get(`${BASEURL}/consignee/${groupId}`);
            setConsignees(response?.data?.products);
        } catch (error) {
            console.error("Error fetching products:", error);
        }
    };


    const editConsignee = async () => {
        try {
            const values = await editForm.validateFields(); // Validate form inputs
            const response = await axios.patch(`${BASEURL}/consigneeupdate/${currentConsignee._id}`, values);

            // Update product in the UI
            const updatedConsignees = products.map((p) =>
                p._id === currentConsignee._id ? { ...p, ...values } : p
            );
            setConsignees(updatedConsignees);
            message.success({
                content: response.data.message,
                duration: 2, // Time before it disappears (in seconds)
                style: {
                    marginTop: "25vh", // Moves it to center vertically
                    textAlign: "center", // Ensures text is centered
                    // Moves it to center horizontally
                }
            });
            // message.success(response.data.message);
            setEditOpen(false); // Close modal after successful edit
        } catch (error) {
            console.error("Error updating product:", error);
            message.error("Failed to update product!");
        }
    };


    useEffect(() => {
        fetchConsignees();
    }, []);


    const deleteConsignee = async (id) => {
        //console.log("Deleting Consignee:", id);

        try {
            await axios.delete(`${BASEURL}/deleteconsignee/${id}`);
            setConsignees(products.filter((product) => product._id !== id));

            message.success({
                content: "Consignee deleted successfully!",
                duration: 2, // Time before it disappears (in seconds)
                style: {
                    marginTop: "25vh", // Moves it to center vertically
                    textAlign: "center", // Ensures text is centered
                    // Moves it to center horizontally
                }
            });

        } catch (error) {
            console.error("Error deleting product:", error);
            message.error("Failed to delete product!");
        }
    };

 
    const handleUpload = async () => {
        if (fileList.length === 0) {
            message.error("Please select a CSV file to upload.");
            return;
        }
    
        const file = fileList[0];
    
        Papa.parse(file.originFileObj, {
            complete: async (result) => {
                let records = result.data.slice(1).map(row => ({
                    name: row[0]?.trim() || "",
                    place: row[1]?.trim() || "",
                    district: row[2]?.trim() || "",
                    mobileNo: row[3]?.trim() || "",
                    groupId: value.id, // ✅ Attach the groupId
                }));
    
                // ✅ Filter out invalid entries (missing required fields)
                records = records.filter(record => record.name && record.place && record.district && record.groupId);
    
                if (records.length === 0) {
                    message.error("No valid records found in the CSV file.");
                    return;
                }
    
                try {
                    const response = await axios.post(`${BASEURL}/uploadconsignee`, { products: records });                    message.success(response.data.message);
                    setConsignees([...products, ...records]);
                    setBulkUploadOpen(false);
                    setFileList([]);
                } catch (error) {
                    console.error("Error uploading CSV:", error);
                    message.error("Failed to upload CSV.");
                }
            },
            header: false
        });
    };
    
    // Table Columns
    const columns = [
        {
            title: "S.N.",
            dataIndex: "serialNumber",
            key: "serialNumber",
            render: (_, __, index) => index + 1, // Generates Serial Numbers
        },
        { title: "Consignee Name", dataIndex: "name", key: "name" },
        { title: "Consignee Place", dataIndex: "place", key: "code" },
        { title: "Consignee District", dataIndex: "district", key: "uom" },
        { title: "Mobile No.", dataIndex: "mobileNo", key: "rate" },
        {
            title: "Actions",
            key: "actions",
            render: (_, record) => (
                <Space>
                    <Button
                        icon={<EditOutlined />}
                        onClick={() => handleEditOpen(record)}
                        style={{ backgroundColor: "#77B254", color: "white", borderColor: "green" }}
                    >
                        Edit
                    </Button>

                    <Popconfirm
                        title="Are you sure to delete this product?"
                        onConfirm={() => deleteConsignee(record._id)}
                        okText="Yes"
                        cancelText="No"
                    >
                        <Button danger icon={<DeleteOutlined />}
                            style={{ backgroundColor: "#C63D2F", color: "white", borderColor: "red" }}                       >
                            Delete
                        </Button>
                    </Popconfirm>
                </Space>
            ),
        },
    ];


    return (
        <div >
            <Typography.Title
                level={2}
                style={{
                    backgroundColor: "#AA2B1D",
                    color: "white",
                    height: "60px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: 0, // Remove default margin
                    textAlign: "center",
                }}
            >
                Consignee Master
            </Typography.Title>



            {/* Add Consignee Button */}
            <div style={{ display: "flex", justifyContent: "center", marginBottom: "20px", marginTop: "20px" }}>
                <Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)} style={{ marginRight: "10px" }}>
                    Add Consignee
                </Button>

                <Button type="default" icon={<UploadOutlined />} onClick={() => setBulkUploadOpen(true)}>
                    Bulk Upload
                </Button>
            </div>

            <Modal
                title="📤 Bulk Upload Consignees"
                open={bulkUploadOpen}
                onCancel={() => setBulkUploadOpen(false)}
                onOk={handleUpload}
                okText="Upload"
                cancelText="Cancel"
                centered
            >
                <p>Please upload a CSV file with the following format:</p>
                <p><b>Name, Place, District, Mobile No</b></p>

                <Upload
                    beforeUpload={() => false}
                    onChange={({ fileList }) => setFileList(fileList)}
                    fileList={fileList}
                    accept=".csv"
                >
                    <Button icon={<UploadOutlined />}>Select CSV File</Button>
                </Upload>
            </Modal>
            {/* {products.length > 0 && (
                <Card title="📜 Consignee List" style={{ marginTop: 20 }}>
                    <Table dataSource={products} columns={columns} rowKey="name" pagination={false} />
                </Card>
            )} */}

            {/* Consignee Form Modal */}
            <Modal
                title="➕ Add a New Consignee"
                open={open}
                onCancel={handleClose}
                onOk={addConsignee}
                okText="Save"
                cancelText="Cancel"
                centered
            >
                <hr />
                <Form form={form} layout="vertical">
                    <Form.Item
                        label="Name of Consignee"
                        name="name"
                        rules={[{ required: true, message: "Please enter Name of Consignee" }]}
                    >
                        <Input placeholder="Enter Name of Consignee" />
                    </Form.Item>
                    <Form.Item
                        label="Place"
                        name="place"
                        rules={[{ required: true, message: "Please enter place" }]}
                    >
                        <Input placeholder="Enter place " />
                    </Form.Item>

                    <Form.Item
                        label="District"
                        name="district"
                        rules={[{ message: "Please enter District" }]}
                    >
                        <Input placeholder="Enter District" />
                    </Form.Item>

                    <Form.Item
                        label="Mobile Number"
                        name="mobileNo"
                        rules={[{ message: "Please enter Mobile Number" }]}
                    >
                        <Input placeholder="Enter Mobile Number" />
                    </Form.Item>
                </Form>
            </Modal>
            <Modal
                title="✏️ Edit Consignee"
                open={editOpen} // Ensure this is linked to editOpen state
                onCancel={() => setEditOpen(false)} // Close modal when clicking outside
                onOk={editConsignee}
                centered
            >
                <hr />
                <Form form={editForm} layout="vertical">
                    <Form.Item
                        label="Name of Consignee"
                        name="name"
                        rules={[{ required: true, message: "Please enter Name of Consignee" }]}
                    >
                        <Input placeholder="Enter Name of Consignee" />
                    </Form.Item>
                    <Form.Item
                        label="Place"
                        name="place"
                        rules={[{ required: true, message: "Please enter place" }]}
                    >
                        <Input placeholder="Enter place " />
                    </Form.Item>

                    <Form.Item
                        label="District"
                        name="district"
                        rules={[{ message: "Please enter District" }]}
                    >
                        <Input placeholder="Enter District" />
                    </Form.Item>

                    <Form.Item
                        label="Mobile Number"
                        name="mobileNo"
                        rules={[{ message: "Please enter Mobile Number" }]}
                    >
                        <Input placeholder="Enter Mobile Number" />
                    </Form.Item>
                </Form>
            </Modal>
            {/* Consignee List */}
            {products.length > 0 && (
                //console.log(products),

                <Card
                    title={
                        <span>
                            <span style={{ color: "#AA2B1D", fontSize: "20px" }}>📜</span> Consignee List
                        </span>
                    }
                    style={{ marginTop: 20 }}
                >
                    <Table dataSource={products} columns={columns} rowKey="id" pagination={false} />
                </Card>


            )}
        </div>
    );
};

export default ConsigneeMaster;


