import React, { useEffect, useState } from "react";
import {
    Button,
    Modal,
    Form,
    Input,
    Table,
    Typography,
    Space,
    Card,
    Popconfirm,
    message
} from "antd";
import { PlusOutlined, EditOutlined, DeleteOutlined } from "@ant-design/icons";
import axios from "axios";
import { useNavigate, useParams } from 'react-router-dom';

const BASEURL = "/api"

const ProductMaster = () => {
    const navigate = useNavigate();
const { groupId } = useParams()
console.log(groupId);

    const [products, setProducts] = useState([]);
    console.log(products);
    const [currentProduct, setCurrentProduct] = useState(null); // Stores Selected Product for Editing
    const [editOpen, setEditOpen] = useState(false); // Controls Edit Modal State
    const [value, setValue] = useState({})
    console.log(value.id);
    const [editForm] = Form.useForm(); // Antd Form Hook
    const [open, setOpen] = useState(false); // Controls Modal State
    const [form] = Form.useForm(); // Antd Form Hook
    const userId =  value.id

    const handleOpen = () => {
        form.resetFields();
        setOpen(true);
    };

    useEffect(() => {
        const savedInfo = localStorage.getItem("info");
        if (savedInfo) {
            const parsedInfo = JSON.parse(savedInfo);
            setValue(parsedInfo);
        }
        else {
            navigate("/");
        }

    }, []);

    const handleEditOpen = (product) => {
        //console.log("Editing Product:", product);
        setCurrentProduct(product);
        editForm.setFieldsValue(product); // Pre-fill form with selected product details
        setEditOpen(true);
    };

    const handleClose = () => setOpen(false);
    // Add Product
    const addProduct = () => {
        form.validateFields().then(async (values) => {
            console.log("values", values);
            console.log("User ID:", value.id);
            const payload = { ...values, groupId };
            try {
                const response = await axios.post(`${BASEURL}/productmaster`, payload);
                // setProducts([...products, response.data.product]); // Update UI
                fetchProducts();
                message.success({
                    content: response.data.message,
                    duration: 2, // Time before it disappears (in seconds)
                    style: {
                        marginTop: "25vh", // Moves it to center vertically
                        textAlign: "center", // Ensures text is centered
                        // Moves it to center horizontally
                    }
                });
                handleClose();
            } catch (error) {
                console.error("Error adding product:", error);
                alert("Failed to add product!");
            }
        });
    };


    const fetchProducts = async () => {
        try {
            const response = await axios.get(`${BASEURL}/products/${groupId}`);
            setProducts(response?.data?.products);
        } catch (error) {
            console.error("Error fetching products:", error);
        }
    };


    const editProduct = async () => {
        try {
            const values = await editForm.validateFields(); // Validate form inputs
            const response = await axios.patch(`${BASEURL}/productupdate/${currentProduct._id}`, values);

            // Update product in the UI
            const updatedProducts = products.map((p) =>
                p._id === currentProduct._id ? { ...p, ...values } : p
            );
            setProducts(updatedProducts);
            message.success({
                content: response.data.message,
                duration: 2, // Time before it disappears (in seconds)
                style: {
                    marginTop: "25vh", // Moves it to center vertically
                    textAlign: "center", // Ensures text is centered
                    // Moves it to center horizontally
                }
            });
            // message.success(response.data.message);
            setEditOpen(false); // Close modal after successful edit
        } catch (error) {
            console.error("Error updating product:", error);
            message.error("Failed to update product!");
        }
    };


    useEffect(() => {
        fetchProducts();
    }, []);


    const deleteProduct = async (id) => {
        //console.log("Deleting Product:", id);

        try {
            await axios.delete(`${BASEURL}/productmaster/${id}`);
            setProducts(products.filter((product) => product._id !== id));

            message.success({
                content: "Product deleted successfully!",
                duration: 2, // Time before it disappears (in seconds)
                style: {
                    marginTop: "25vh", // Moves it to center vertically
                    textAlign: "center", // Ensures text is centered
                    // Moves it to center horizontally
                }
            });

        } catch (error) {
            console.error("Error deleting product:", error);
            message.error("Failed to delete product!");
        }
    };


    // Table Columns
    const columns = [
        {
            title: "S.N.",
            dataIndex: "serialNumber",
            key: "serialNumber",
            render: (_, __, index) => index + 1, // Generates Serial Numbers
        },
        { title: "Product Name", dataIndex: "name", key: "name" },
        { title: "Product Code", dataIndex: "code", key: "code" },
        { title: "Unit of Measurement", dataIndex: "uom", key: "uom" },
        { title: "Rate", dataIndex: "rate", key: "rate" },
        {
            title: "Actions",
            key: "actions",
            render: (_, record) => (
                <Space>
                    <Button
                        icon={<EditOutlined />}
                        onClick={() => handleEditOpen(record)}
                        style={{ backgroundColor: "#77B254", color: "white", borderColor: "green" }}
                    >
                        Edit
                    </Button>

                    <Popconfirm
                        title="Are you sure to delete this product?"
                        onConfirm={() => deleteProduct(record._id)}
                        okText="Yes"
                        cancelText="No"
                    >
                        <Button danger icon={<DeleteOutlined />}
                            style={{ backgroundColor: "#C63D2F", color: "white", borderColor: "red" }}                       >
                            Delete
                        </Button>
                    </Popconfirm>
                </Space>
            ),
        },
    ];

    return (
        <div >
            <Typography.Title
                level={2}
                style={{
                    backgroundColor: "#AA2B1D",
                    color: "white",
                    height: "60px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: 0, // Remove default margin
                    textAlign: "center",
                }}
            >
                Product Master
            </Typography.Title>



            {/* Add Product Button */}
            <div style={{ display: "flex", justifyContent: "center", marginBottom: "20px", marginTop: "20px" }}>
                <Button type="primary" icon={<PlusOutlined />} onClick={handleOpen}>
                    Add Product
                </Button>
            </div>

            {/* Product Form Modal */}
            <Modal
                title="➕ Add a New Product"
                open={open}
                onCancel={handleClose}
                onOk={addProduct}
                okText="Save"
                cancelText="Cancel"
                centered
            >
                <hr />
                <Form form={form} layout="vertical">
                    <Form.Item
                        label="Product Name"
                        name="name"
                        rules={[{ required: true, message: "Please enter product name" }]}
                    >
                        <Input placeholder="Enter product name" />
                    </Form.Item>
                    <Form.Item
                        label="Product Code"
                        name="code"
                        rules={[{ required: true, message: "Please enter product code" }]}
                    >
                        <Input placeholder="Enter product code" />
                    </Form.Item>

                    <Form.Item
                        label="Unit of Measurement (UOM)"
                        name="uom"
                        rules={[{ message: "Please enter unit of measurement" }]}
                    >
                        <Input placeholder="Enter unit of measurement" />
                    </Form.Item>

                    <Form.Item
                        label="Product Rate"
                        name="rate"
                        rules={[{ message: "Please enter Product Rate" }]}
                    >
                        <Input placeholder="Enter Product Rate" />
                    </Form.Item>
                </Form>
            </Modal>
            <Modal
                title="✏️ Edit Product"
                open={editOpen} // Ensure this is linked to editOpen state
                onCancel={() => setEditOpen(false)} // Close modal when clicking outside
                onOk={editProduct}
                centered
            >
                <hr />
                <Form form={editForm} layout="vertical">
                    <Form.Item
                        label="Product Name"
                        name="name"
                        rules={[{ required: true, message: "Please enter product name" }]}
                    >
                        <Input placeholder="Enter product name" />
                    </Form.Item>
                    <Form.Item
                        label="Product Code"
                        name="code"
                        rules={[{ required: true, message: "Please enter product code" }]}
                    >
                        <Input placeholder="Enter product code" />
                    </Form.Item>
                    <Form.Item
                        label="Unit of Measurement (UOM)"
                        name="uom"
                        rules={[{ message: "Please enter unit of measurement" }]}
                    >
                        <Input placeholder="Enter unit of measurement" />
                    </Form.Item>

                    <Form.Item
                        label="Product Rate"
                        name="rate"
                        rules={[{ message: "Please enter Product Rate" }]}
                    >
                        <Input placeholder="Enter Product Rate" />
                    </Form.Item>
                </Form>
            </Modal>
            {/* Product List */}
            {products.length > 0 && (
                //console.log(products),

                <Card
                    title={
                        <span>
                            <span style={{ color: "#AA2B1D", fontSize: "20px" }}>📜</span> Product List
                        </span>
                    }
                    style={{ marginTop: 20 }}
                >
                    <Table dataSource={products} columns={columns} rowKey="id" pagination={false} />
                </Card>


            )}
        </div>
    );
};

export default ProductMaster;


