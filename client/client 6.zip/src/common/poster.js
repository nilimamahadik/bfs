




import React, { useRef, useEffect, useState } from 'react';
import logo from '../image/aiimslogo.jpg';
import { makeStyles } from '@material-ui/core/styles';
// import { Typography, TextField, Grid, Paper, Button } from '@material-ui/core';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import footer4 from '../image/footer4.jpg'
import { useNavigate } from "react-router-dom";
import numberToWords from "number-to-words";
import './poster.css'
import {
  Box,
  Typography,
  Divider,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  FormControlLabel,
  Checkbox,
  Card,
  CardContent,
  Modal,
  Fade,
  Backdrop,
} from "@mui/material";
import { useReactToPrint } from 'react-to-print';
import { formatDate } from '../commonfunction/formatDate';
import TranslateButton from './translationButton';

const BASEURL = "/api"


const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: theme.spacing(4),
  },
  content: {
    padding: theme.spacing(4),
  },
  image: {
    maxWidth: '400px',
    maxHeight: '400px',

  },
}));

const Poster = (props) => {
  const param = useParams()
  console.log(param);
  const classes = useStyles();
  const componentsPDF = useRef();
  const [data, setData] = useState({});
  console.log(data);
  const [open, setOpen] = useState(false); // Modal state

  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [value, setValue] = useState({});
  console.log(value);
  const [columns, setColumns] = useState({
    description: true,
    articles: true,
    weight: true,
    rate: true,
    totalFreight: true,
    advance: true,
    toPay: true,
  });
  const navigate = useNavigate();
  const componentRef = React.useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  useEffect(() => {
    const googleTranslateScript = document.createElement("script");
    googleTranslateScript.type = "text/javascript";
    googleTranslateScript.src =
      "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    document.body.appendChild(googleTranslateScript);
  }, []);

  useEffect(() => {
    const getsingleusers = async () => {
      const get = axios.get(`${BASEURL}/getsingleusers/${param.id}`)
        .then((res) => {

          // console.log(res);
          setData(res.data.data);
        })
        .catch((err) => {
          console.log(err);
        })
    }
    getsingleusers();
  }, [])

  useEffect(() => {
    const savedUser = localStorage.getItem("link");
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setValue(parsedUser);
    }
    const savedInfo = localStorage.getItem("info");
    if (savedInfo) {
      const parsedInfo = JSON.parse(savedInfo);
      setValue(parsedInfo);
    }
  }, []);


  const totalInWords = data.total
    ? numberToWords.toWords(data.total).replace(/\b\w/g, (c) => c.toUpperCase()) + " Rupees Only"
    : "Zero Rupees Only";

  return (


    <>
      <div style={{ paddingBottom: "100px" }}>
        <Box textAlign="center" sx={{ mb: 3 }}>

        </Box>

        {/* Modal for Column Selection */}
        <Modal
          open={open}
          onClose={() => setOpen(false)}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{ timeout: 300 }}
        >
          <Fade in={open}>
            <Box
              sx={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: 400,
                bgcolor: "background.paper",
                boxShadow: 24,
                p: 4,
                borderRadius: 2,
              }}
            >
              <Typography variant="h6" align="center" gutterBottom>
                Select Options to Print
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 1 }}>
                {Object.keys(columns).map((key) => (
                  <FormControlLabel
                    key={key}
                    control={
                      <Checkbox
                        checked={columns[key]}
                        onChange={() =>
                          setColumns((prev) => ({ ...prev, [key]: !prev[key] }))
                        }
                        sx={{
                          color: "black",
                          "&.Mui-checked": { color: "secondary" },
                        }}
                      />
                    }
                    label={key.replace(/([A-Z])/g, " $1").trim()}
                  />
                ))}
              </Box>
              <Box sx={{ textAlign: "center", mt: 3 }}>
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={() => setOpen(false)}
                  sx={{ mr: 2 }}
                >
                  Close
                </Button>

              </Box>
            </Box>
          </Fade>
        </Modal>
        <br />



        <div ref={componentRef} >
          <Box sx={{ maxWidth: 700, margin: "auto", padding: "30px", backgroundColor: "#FDFAFB", boxShadow: 3, borderRadius: 2, color: "black", border: "1px solid black" }}>


            <Typography variant="h6" align="center" fontWeight="bold" sx={{ marginBottom: "1px", fontSize: "30px" }}>
              {value.id}
            </Typography>

            <Typography variant="body2" align="center" sx={{ marginBottom: "1px", fontSize: "15px" }}>
              {value.address}
            </Typography>
            <Typography variant="body2" align="center" fontWeight={500}>
              Received goods as per details below for carriage Subject to condition overleaf
            </Typography>
            <Divider sx={{ my: 2, borderColor: "#AA2B1D", borderWidth: "1px" }} />

            {/* Details Section */}
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography>
                  <strong>Receipt No:</strong> <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.receipt_number}</span>
                </Typography>
              </Grid>
              <Grid item xs={6} >
                <Typography>
                  <strong>Date:</strong> <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{formatDate(data?.createdAt)}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>From:</strong> <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.from}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>Driver Name:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.transport_driver_name}</span>
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography>
                  <strong>Truck No:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.transport_number}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>Consignor:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.supplier_name}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>Place:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.address}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>Consignee:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.vendor_name}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>Place:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.ship_to_address1}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>District:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.ship_to_district}</span>
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography>
                  <strong>Mobile No:</strong>{" "}
                  <span style={{ borderBottom: "", color: "rgba(16, 16, 16, 0.73)" }}>{data?.mobileNo}</span>
                </Typography>
              </Grid>
            </Grid>





            <TableContainer component={Paper} sx={{ mt: 2, borderRadius: 0, boxShadow: 2 }}>
              <Table>
                <TableHead sx={{ backgroundColor: "#AA2B1D", boxShadow: 5 }}>
                  <TableRow>
                    {columns.description && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>Description</TableCell>}
                    {columns.articles && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>Unit of Measure</TableCell>}
                    {columns.weight && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>No. of Articles</TableCell>}
                    {columns.rate && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>Rate</TableCell>}
                    {columns.totalFreight && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>Total Freight (₹)</TableCell>}
                    {columns.advance && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>Advance (₹)</TableCell>}
                    {columns.toPay && <TableCell sx={{ color: "white", fontWeight: "bold", padding: "6px" }}>To Pay (₹)</TableCell>}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data?.productDetails?.map((product, index) => (
                    <TableRow key={index}>
                      {columns.description && <TableCell>{product.product_name}</TableCell>}
                      {columns.articles && <TableCell>{product.uom}</TableCell>}
                      {columns.weight && <TableCell>{product.weight}</TableCell>}
                      {columns.rate && <TableCell>{product.rate}</TableCell>}
                      {columns.totalFreight && <TableCell>{product.total_freight}</TableCell>}
                      {columns.advance && <TableCell>{product.advance_paid}</TableCell>}
                      {columns.toPay && <TableCell>{product.to_pay}</TableCell>}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            <Divider sx={{ my: 2 }} />

            {/* Payment Section */}
            <Grid container spacing={2}>
              <Grid item xs={3}><Typography><strong>Advance Cash:</strong> {data.sc}</Typography></Grid>
              <Grid item xs={3}><Typography><strong>Diesel:</strong> {data.hamali}</Typography></Grid>
            </Grid>

            <Typography style={{ marginTop: "15px" }}>
              <strong> To Pay Rs :</strong>  {totalInWords}
              <span style={{ borderBottom: "1px dotted  #AA2B1D" }}></span>
            </Typography>

            <Divider sx={{ my: 2, borderColor: "#AA2B1D", borderWidth: "1px" }} />

            {/* Footer Section */}
            <Typography variant="body2" align="center">
              दोन प्रतिवर रबर स्टैम्प व सहीनिशी पोहोच देणे . ७ दिवसाच्या आत पोहोच न आल्यास भाडे मिळणार नाही.
            </Typography>
            <Typography variant="body2" align="center">
              We have carefully read the terms and conditions of the back here and we undertake to abide by the said terms and conditions.
            </Typography>

            <Box sx={{ display: "flex", justifyContent: "space-between", mt: 3 }}>
              <Typography variant="body2"><strong>Driver Signature:</strong> __________</Typography>
              <Typography variant="body2"><strong>For: {value.id}</strong></Typography>
            </Box>


          </Box>
        </div>


        <div className='no-print'>
          <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", mt: 3 }}>
            {/* Left Side: Buttons */}
            <Box sx={{ display: "flex", gap: 2 }}>
              <Button variant="contained" color="primary" onClick={() => navigate(-1)}>
                🔙 Back
              </Button>
              <Button variant="contained" color="primary" onClick={() => setOpen(true)}>
                📄 Select Print Options
              </Button>
              <Button variant="contained" color="primary" onClick={handlePrint}>
                🖨️ Print
              </Button>
            </Box>

         
             <TranslateButton/>
             
          </Box>

        </div>
      </div >
    </>
  );
};

export default Poster;