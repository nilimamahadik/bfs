import { useEffect, useState } from "react";
import { Box, Button, Menu, MenuItem } from "@mui/material";

function TranslateButton() {
  const [anchorEl, setAnchorEl] = useState(null);
  const [googleLoaded, setGoogleLoaded] = useState(false);

  useEffect(() => {
    const loadGoogleTranslate = () => {
      if (window.google && window.google.translate) {
        initializeGoogleTranslate();
        return;
      }

      const script = document.createElement("script");
      script.src =
        "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      script.async = true;
      script.onload = () => initializeGoogleTranslate();
      document.body.appendChild(script);
    };

    window.googleTranslateElementInit = initializeGoogleTranslate;
    loadGoogleTranslate();
  }, []);

  const initializeGoogleTranslate = () => {
    if (window.google && window.google.translate) {
      new window.google.translate.TranslateElement(
        { pageLanguage: "en", autoDisplay: false },
        "google_translate_element"
      );
      setGoogleLoaded(true);
    } else {
      console.error("Google Translate script failed to load.");
    }
  };

  const handleClick = (event) => {
    if (!googleLoaded) {
      alert("Google Translate is still loading. Please wait.");
      return;
    }
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (lang) => {
    setAnchorEl(null);
    if (lang) {
      const select = document.querySelector(".goog-te-combo");
      if (select) {
        select.value = lang;
        select.dispatchEvent(new Event("change"));
      }
    }
  };

  return (
    <Box>
      <Button variant="contained" color="primary" onClick={handleClick}>
        Translate
      </Button>
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => handleClose(null)}>
        <MenuItem onClick={() => handleClose("mr")}>Marathi</MenuItem>
        <MenuItem onClick={() => handleClose("hi")}>Hindi</MenuItem>
      </Menu>

      {/* Hidden Google Translate Widget */}
      <Box display="none">
        <div id="google_translate_element"></div>
      </Box>
    </Box>
  );
}

export default TranslateButton;
