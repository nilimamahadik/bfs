import { Dropdown, Menu, message, Table } from "antd";
import "bootstrap-icons/font/bootstrap-icons.css";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card, TextField } from '@material-ui/core';
import axios from 'axios';
import { EditOutlined } from "@ant-design/icons";
import { Typography } from '@material-ui/core';
import { useParams } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import Button from '@mui/material/Button'
import Drawer from "./drawer";
import { RWebShare } from "react-web-share";
import { Box, CardContent, Grid, IconButton, Toolbar } from "@mui/material";
import { formatDate } from "../commonfunction/formatDate";
import FormData from "./form";
import { Col, Form, Select, Row, Checkbox, Modal, Input, } from "antd";
import FormDataInfo from "./form";
import { LuEye } from "react-icons/lu";
import { IoMdAdd } from "react-icons/io";
import { GiRegeneration } from "react-icons/gi";

import { FaRegShareSquare } from "react-icons/fa";
import { Login } from "@mui/icons-material";

//for developement
// const BASEURL = "http://localhost:5000/api"

//for production

const BASEURL = "/api"

function CustomTable({ data, setData }) {
  console.log(data);

  const [columnItems, setColumnItems] = useState([]);
  const [columnsToShow, setColumnsToShow] = useState([]);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingReceipt, setEditingReceipt] = useState(null);
  const [form] = Form.useForm();

  const handleEdit = (record) => {
    console.log(record);

    setEditingReceipt(record);
    form.setFieldsValue(record); // Pre-fill form with selected row data
    setEditModalOpen(true);
  };

  // 🛠 Handle Saving Edits
  const handleSaveEdit = async () => {

    try {
      const values = await form.validateFields();
      console.log(values);

      const response = await axios.patch(`${BASEURL}/update_receipt/${editingReceipt._id}`, values);
      console.log(response);

      message.success("Receipt updated successfully!");
      setEditModalOpen(false);

      setData((prevData) =>
        prevData.map((item) => (item._id === editingReceipt._id ? { ...item, ...values } : item))
      );
    } catch (error) {
      console.error("Error updating receipt:", error);
      message.error("Failed to update receipt.");
    }
  };

  const handleGraceMarks = async (record) => {
    try {
      const confirmed = window.confirm(`Regenerate new receipt for ${record.receipt_number}?`);
      if (!confirmed) return;

      const response = await axios.post(`${BASEURL}/regenerate_receipt`, {
        receipt_id: record._id,
      });
      message.success(`Receipt regenerated! New Number: ${response.data.newReceiptNumber}`);
      window.location.reload();
    } catch (error) {
      console.error("Error regenerating receipt:", error);
      message.error("Failed to regenerate receipt!");
    }
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "receiptNumber"
    },
    {
      title: "LR No.",
      dataIndex: "receipt_number",
      key: "receiptNumber"
    },
    {
      title: "Name of Consignor",
      dataIndex: "vendor_name",
      key: "name",
    },
    {
      title: "Address",
      dataIndex: "address",
      key: "address",
      responsive: ["md"]
    },
    {

      title: "Consignee",

      dataIndex: "supplier_name",

      key: "phone",

      responsive: ["md"]

    },

    {
      title: "Place",
      dataIndex: "ship_to_address1",
      key: "name",
    },
    {
      title: "District",
      dataIndex: "ship_to_district",
      key: "name",
    },
    {
      title: "Mobile No.",
      dataIndex: "mobileNo",
      key: "name",
    },
    {
      title: "Driver Name",
      dataIndex: "transport_driver_name",
      key: "name",
    },

    {
      title: "Truck No.",
      dataIndex: "transport_number",
      key: "name",
    },

    {
      title: "Products",
      key: "products",
      render: (_, record) =>
        record.productDetails?.map((product, index) => (
          <div key={index} style={{ borderBottom: "1px solid #ddd", paddingBottom: "5px", marginBottom: "5px" }}>
            {product.product_name} <br />

          </div>
        )),
    },
    {
      title: "Code",

      key: "products",
      render: (_, record) =>
        record.productDetails?.map((product, index) => (
          <div key={index} style={{ borderBottom: "1px solid #ddd", paddingBottom: "5px", marginBottom: "5px" }}>
            {product.product_code}

          </div>
        )),
    },


    {
      title: "Total Freight",
      key: "products",
      render: (_, record) =>
        record.productDetails?.map((product, index) => (
          <div key={index} style={{ borderBottom: "1px solid #ddd", paddingBottom: "5px", marginBottom: "5px" }}>
            {product.total_freight}

          </div>
        )),
    },
    {
      title: "Advance",
      key: "products",
      render: (_, record) =>
        record.productDetails?.map((product, index) => (
          <div key={index} style={{ borderBottom: "1px solid #ddd", paddingBottom: "5px", marginBottom: "5px" }}>



            {product.advance_paid}

          </div>
        )),
    },
    {
      title: "To Pay",
      key: "products",
      render: (_, record) =>
        record.productDetails?.map((product, index) => (
          <div key={index} style={{ borderBottom: "1px solid #ddd", paddingBottom: "5px", marginBottom: "5px" }}>


            {product.to_pay}

          </div>
        )),
    },
    {
      title: "Edit",
      key: "actions",
      render: (_, record) => (

        <>
          <EditOutlined
            onClick={() => handleEdit(record)}
            style={{ color: "#1890ff", marginRight: 10, cursor: "pointer", fontSize: "20px" }}

          />

        </>
      ),
    },
    {
      title: "Receipt",
      dataIndex: "receipt",
      key: "receipt",
      render: (text, record) => (
        <Link to={`/poster/${record._id}`}>
          <LuEye size={20} color="primary" />
        </Link>
      ),
    },
    {
      title: "Regenerate",
      key: "regenerate",
      render: (_, record) => (
        // <Button 
        //   type="primary" 
        //   onClick={() => handleGraceMarks(record)}  // ✅ Now passes the correct receipt
        //   style={{ backgroundColor: "#f39c12", borderColor: "#f39c12" }}
        // >
        <GiRegeneration color="#1976d2" size={30} onClick={() => handleGraceMarks(record)} />

      ),
    },

    {

      title: "Share",

      dataIndex: "share",

      key: "share",
      render: (text, record) => (
        <RWebShare
          data={{
            text: " BHARAT ONLINE",
            url: `${window.location.protocol}//${window.location.host}/poster/${record._id}`,
            title: " BHARAT ONLINE",
          }}
        >
          <FaRegShareSquare size={20} color="#1677ff" />
          {/* <Button variant="contained">Share </Button> */}
        </RWebShare>
      )
    },



  ];

  useEffect(() => {
    setColumnItems(menuItems);
    setColumnsToShow(columns);
  }, []);

  const colVisibilityClickHandler = (col) => {
    const ifColFound = columnsToShow.find((item) => item.key === col.key);
    if (ifColFound) {
      const filteredColumnsToShow = columnsToShow.filter(
        (item) => item.key !== col.key
      );
      setColumnsToShow(filteredColumnsToShow);
    } else {
      const foundIndex = columns.findIndex((item) => item.key === col.key);
      const foundCol = columns.find((item) => item.key === col.key);
      let updatedColumnsToShow = [...columnsToShow];
      updatedColumnsToShow.splice(foundIndex, 0, foundCol);
      setColumnsToShow(updatedColumnsToShow);
    }
  };

  const menuItems = columns.map((item) => {
    return {
      key: item.key,
      label: <span>{item.title}</span>
    };
  });

  const addKeys = (arr) => {
    return arr.map((item, index) => {
      return {
        ...item,
        receiptNumber: index + 1,
        createdAt: formatDate(item?.createdAt)

      }
    });
  }
  return (
    <div>
      <div style={{ marginBottom: "30px" }}>
        <Dropdown
          overlay={
            <Menu onClick={colVisibilityClickHandler} items={columnItems} />
          }
          placement="bottomLeft"
        >
          <Button>Column Visibility</Button>
        </Dropdown>
      </div>
      <div>
        <div>
          <Table
            scroll={{ x: true }}
            columns={columnsToShow}
            dataSource={data ? addKeys(data) : []}
          />
        </div>


      </div>

      <Modal
        open={editModalOpen}
        // onOk={handleSaveEdit}
        onCancel={() => setEditModalOpen(false)}
        centered
        style={{marginTop:"90px"}}
        footer={null}
      >
        {/* Custom Styled Title with Horizontal Line */}
        <div style={{ textAlign: "center", fontSize: "21px", fontWeight: "bold", color: "rgb(170, 43, 29)" }}>
          Edit Lorry Receipt
        </div>

        <hr style={{ marginBottom: "10px", borderTop: "2px solid #ccc" }} /> {/* Horizontal Line */}

        {/* Form Fields */}
        <Form form={form} layout="vertical">
          <Form.Item name="vendor_name" label="Name of Consignor" style={{ marginBottom: "8px" }}>
            <Input size="small" />
          </Form.Item>

          <Form.Item name="address" label="Address" style={{ marginBottom: "8px" }}>
            <Input size="small" />
          </Form.Item>

          <Form.Item name="supplier_name" label="Name of Consignee" style={{ marginBottom: "8px" }}>
            <Input size="small" />
          </Form.Item>

          <Form.Item name="transport_number" label="Truck No." style={{ marginBottom: "8px" }}>
            <Input size="small" />
          </Form.Item>

          <Form.Item name="transport_driver_name" label="Driver Name" style={{ marginBottom: "8px" }}>
            <Input size="small" />
          </Form.Item>

          <Form.Item name="mobileNo" label="Mobile" style={{ marginBottom: "8px" }}>
            <Input size="small" />
          </Form.Item>
        </Form>


        {/* Footer Buttons */}
        <div style={{ textAlign: "center", marginTop: "20px" }}>
          <Button type="primary" onClick={handleSaveEdit} style={{ marginRight: "10px" }}>
            Save
          </Button>
          <Button onClick={() => setEditModalOpen(false)}>Cancel</Button>
        </div>
      </Modal>

    </div>
  );
}

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "auto", // Default for mobile
  maxHeight: "98vh", // Set maximum height to 90% of the viewport height
  overflowY: "auto", // Enable vertical scrolling if content exceeds the height
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 1,
  "@media (min-width: 600px)": { // For larger screens (web)
    width: "70%",
    p: 4,
  },
};

const drawerWidth = 240;

const FormExampleAdmin = (props) => {
  const params = useParams()
  const [data, setData] = useState([])
  const [value, setValue] = useState({})
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [graceOpen, setGraceOpen] = useState(false)
  const [modalForm] = Form.useForm();

  const [formData, setFormData] = useState({
    vendor_name: "",
    address: "",
    supplier_name: "",
    ship_to_address1: "",
    ship_to_district: "",
    transport_mode: "",
    transport_number: "",
    transport_driver_name: "",
    product_name: "",
    product_code: "",
    total_freight: "",
    advance_paid: "",
    to_pay: "",
  })

  const getallusers = async () => {

    const get = axios.get(`${BASEURL}/getallusers/${params.id}`)
      .then((res) => {
        setData(res.data.data);
        //  console.log(res.data);
        localStorage.setItem("count", JSON.stringify(res.data));
      })
      .catch((err) => {
        console.log(err);
      })
  }
  useEffect(() => {
    getallusers();

  }, []);


  useEffect(() => {
    const savedInfo = localStorage.getItem("info");
    if (savedInfo) {
      const parsedInfo = JSON.parse(savedInfo);
      setValue(parsedInfo);
    }
    else {
      navigate("/");
    }

  }, []);


  const handleGraceMarks = () => {
    // console.log(gradeData)
    setGraceOpen(true)
  }
  // console.log(modalForm.getFieldsValue());


  const handleUserClose = () => {
    setGraceOpen(false)
    modalForm.resetFields()
  }

  return (
    <>
      <div >




        <Box display="flex" justifyContent="center" alignItems="center" style={{ marginTop: "40px" }} >
          {/* <h2><u>Contributors</u></h2> */}
          <Button variant="contained" type="submit" style={{ marginRight: "10px" }} onClick={handleGraceMarks} startIcon={<IoMdAdd />} >   Generate   </Button>
        </Box>

        <Box justifyContent="center" alignItems="center" >
          <CustomTable data={data} setData={setData} />
        </Box>



      </div>
      <FormDataInfo
        open={graceOpen}
        handleClose={handleUserClose}
        props={props}
        style={style}
        modalForm={modalForm}
      />
    </>
  );

}
export default FormExampleAdmin;
