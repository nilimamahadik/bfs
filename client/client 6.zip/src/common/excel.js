import React, { useState, useEffect } from "react";
import { CSVLink } from 'react-csv';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Link } from "react-router-dom";
import { LuEye } from "react-icons/lu";
import { formatDate } from "../commonfunction/formatDate";
import { Dropdown, Menu, Table } from "antd";
import Button from '@mui/material/Button'
import { Box, CardContent, Grid, IconButton, Toolbar } from "@mui/material";
import { DataTable } from "../commonfunction/Datatable";
import { PropaneRounded } from "@mui/icons-material";
import ExportCSV from "./ecportcsv";

//for developement
// const BASEURL = "http://localhost:5000/api"

//for production

const BASEURL = "/api"



const Sheet = () => {
  const params = useParams()
  const [data, setData] = useState([])
  const [users, setUsers] = useState([])
  // console.log(params);

  useEffect(() => {
    fetch(`${BASEURL}/getallusers/${params.id}`)
      .then(response => response.json())
      .then(json => {
        // console.log("json", json);

        let data = json.data.map((item) => ({
          address: item.address,
          amount: item.amount,
          date: item.date,
          name: item.name,
          receiver: item.receiver
        }));

        // console.log("data",data);

        setUsers(data);
      });

  }, []);

  const getallusers = async () => {

    const get = axios.get(`${BASEURL}/getallusers/${params.id}`)
      .then((res) => {
        setData(res.data.data);
        //  console.log(res.data);
        localStorage.setItem("count", JSON.stringify(res.data));
      })
      .catch((err) => {
        console.log(err);
      })
  }
  useEffect(() => {
    getallusers();

  }, []);

  const columns = [
    { field: "id", headerName: "Sr.No.", width: 50 },
    { field: "Date", headerName: "Date", width: 100 },
    { field: "receipt_number", headerName: "LR No.", width: 130 },
    { field: "vendor_name", headerName: "Name of Consignor", width: 100 },
    { field: "address", headerName: "Address", width: 100 },
    { field: "supplier_name", headerName: "Consignee Name", width: 100 },
    { field: "ship_to_address1", headerName: "Place", width: 100 },
    { field: "ship_to_district", headerName: "District", width: 100 },
    { field: "transport_driver_name", headerName: "Driver Name", width: 100 },
    { field: "transport_number", headerName: "Transport Number", width: 100 },

    {
      field: "products",
      headerName: "Products",
      width: 100,
      renderCell: (params) => {
        // //console.log("params", params); 
        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >
                <strong>{product.product_name}</strong> 
                
              </div>
            ))}
          </div>
        );
      },
    },
    {
      field: "Code", headerName: "Code", width: 70,
      renderCell: (params) => {
        //console.log("params", params);

        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >

                {product.product_code}
              </div>
            ))}
          </div>
        );
      },
    },
    {
      field: "UOM", headerName: "Unit of Measurement", width: 100,
      renderCell: (params) => {
        //console.log("params", params);

        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >

                {product.uom}
              </div>
            ))}
          </div>
        );
      },
    },
    {
      field: "articles", headerName: "No. of Articles", width: 100,
      renderCell: (params) => {
        //console.log("params", params);

        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >

                {product.weight}
              </div>
            ))}
          </div>
        );
      },
    },
    {
      field: "total", headerName: "Total Freight", width: 100,
      renderCell: (params) => {

        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >

                {product.total_freight}
              </div>
            ))}
          </div>
        );
      },
    },
    {
      field: "Advance", headerName: "Advance", width: 100,
      renderCell: (params) => {

        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >

                {product.advance_paid}
              </div>
            ))}
          </div>
        );
      },
    },
    {
      field: "to_pay", headerName: "To Pay", width: 100,
      renderCell: (params) => {

        return (
          <div>
            {params.row.productDetails?.map((product, index) => (
              <div
                key={index}
                style={{
                  borderBottom: "1px solid #ddd",
                  paddingBottom: "5px",
                  marginBottom: "5px",
                }}
              >

                {product.to_pay}
              </div>
            ))}
          </div>
        );
      },
    },
  ];

  const rows = data?.map((item, index) => {
    console.log("item", item); 

    return {
      id: index + 1,
      Date: formatDate(item.createdAt),
      receipt_number: item.receipt_number,
      supplier_name: item.supplier_name,
      vendor_name: item.vendor_name,
      address: item.address,
      ship_to_address1: item.ship_to_address1,
      ship_to_district: item.ship_to_district,
      transport_driver_name: item.transport_driver_name,
     transport_number: item.transport_number,
      productDetails: item.productDetails || [], 
    };
  }) || [];


  return (
    <div style={{ padding: "10px", fontWeight: "400" }}>
      <ExportCSV data={rows} />
      
      <DataTable rows={rows} columns={columns}  m/>
    </div>
  );
};

export default Sheet;
