import React from "react";
import { CSVLink } from "react-csv";

const ExportCSV = ({ data }) => {
  const csvHeaders = [
    { label: "Sr.No.", key: "id" },
    { label: "Date", key: "Date" },
    { label: "LR No.", key: "receipt_number" },
    { label: "Name of Dealer", key: "vendor_name" },
    { label: "Address", key: "address" },
    { label: "Supplier Name", key: "supplier_name" },
    { label: "Place", key: "ship_to_address1" },
    { label: "District", key: "ship_to_district" },
    { label: "Driver Name", key: "transport_driver_name" },
    { label: "Transport Number", key: "transport_number" },
    { label: "Products", key: "products" }, 
    { label: "Code", key: "product_codes" },
    { label: "Total Freight", key: "total_freight" },
    { label: "Advance", key: "advance_paid" },
    { label: "To Pay", key: "to_pay" },
  ];

  const formattedData = data.map((row, index) => ({
    id: index + 1,
    Date: row.Date,
    receipt_number: row.receipt_number,
    vendor_name: row.vendor_name,
    address: row.address,
    supplier_name: row.supplier_name,
    ship_to_address1: row.ship_to_address1,
    ship_to_district: row.ship_to_district,
    transport_driver_name: row.transport_driver_name,
    transport_number: row.transport_number,

    // Flatten product details into a comma-separated string
    products: row.productDetails?.map((p) => p.product_name).join(", ") || "",
    product_codes: row.productDetails?.map((p) => p.product_code).join(", ") || "",
    total_freight: row.productDetails?.map((p) => p.total_freight).join(", ") || "",
    advance_paid: row.productDetails?.map((p) => p.advance_paid).join(", ") || "",
    to_pay: row.productDetails?.map((p) => p.to_pay).join(", ") || "",
  }));

  return (
    <CSVLink data={formattedData} headers={csvHeaders} filename="export.csv">
      <button style={{ padding: "8px 15px", background: "#007bff", color: "white", border: "none", cursor: "pointer" }}>
        Export to CSV
      </button>
    </CSVLink>
  );
};

export default ExportCSV;