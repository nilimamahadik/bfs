

import React, { useEffect, useState } from "react";
import {
  Box,
  CssBaseline,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Collapse,
  Divider,
} from "@mui/material";
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  Event as EventIcon,
  Group as GroupIcon,
  ExitToApp as ExitToAppIcon,
  ExpandMore as ExpandMoreIcon,
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { ExpandLess, ExpandMore } from "@mui/icons-material";
import { MdProductionQuantityLimits } from "react-icons/md";
import { Link } from "react-router-dom";
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import DownloadForOfflineIcon from '@mui/icons-material/DownloadForOffline';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import obbb from "../image/obbb.jpg";
import DescriptionIcon from "@mui/icons-material/Description";
import CategoryIcon from "@mui/icons-material/Category";
import { FaHandshake } from "react-icons/fa6";

const drawerWidth = 240;

const Sidebar = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [openMaster, setOpenMaster] = useState(false);

  const [value, setValue] = useState({})
  // console.log(value);

  const navigate = useNavigate();
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleDrawerCollapse = () => {
    setDrawerOpen(!drawerOpen);
  };
  const submit = () => {
    navigate(`/csv/${value.id}`);
  }
  const drawer = (
    <div>
      <Toolbar
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <img
          src={obbb}
          alt="Logo"
          style={{ height: "120px", width: "120px" }}
        />

      </Toolbar>
      <Divider sx={{ bgcolor: "black", height: "1px" }} />

      {/* 
      <List>
        {[
          { text: "Dashboard", icon: <DashboardIcon sx={{ color: "#AA2B1D" }} />, path: `/admindashhh/${value.id}` },

          { text: "Product Master", icon: <CategoryIcon sx={{ color: "#AA2B1D" }} />, path: `/productmaster/${value.id}` },
          { text: "Consignee Master", icon: <CategoryIcon sx={{ color: "#AA2B1D" }} />, path: `/consigneemaster/${value.id}` },
          
          { text: "Generate LR", icon: <DescriptionIcon sx={{ color: "#AA2B1D" }} />, path: `/form/admin/${value.id}` },
          { text: "User Management", icon: <ManageAccountsIcon sx={{ color: "#AA2B1D" }} />, path: "/userlist" },
          { text: "View Profile", icon: <AccountBoxIcon sx={{ color: "#AA2B1D" }} />, path: "/profile" },
          { text: "Logout", icon: <ExitToAppIcon sx={{ color: "#AA2B1D" }} />, path: "/" },
        ].map((item, index) => (
          <div key={index}>
            <ListItem button component={Link} to={item.path}>
              <ListItemIcon>{item.icon}</ListItemIcon>
              {drawerOpen && <ListItemText primary={item.text} />}
            </ListItem>
            <Divider sx={{ bgcolor: "black", height: "1px" }} />
          </div>
        ))}

        <ListItem button onClick={submit}>
          <ListItemIcon>
            <DownloadForOfflineIcon sx={{ color: "#AA2B1D" }} />
          </ListItemIcon>
          {drawerOpen && <ListItemText primary="Download" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />
      </List> */}


      <List>
        {/* Dashboard */}
        <ListItem button component={Link} to={`/admindashhh/${value.id}`}>
          <ListItemIcon><DashboardIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="Dashboard" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />

        {/* Master Section - Expandable */}
        <ListItem button onClick={() => setOpenMaster(!openMaster)}>
          <ListItemIcon><CategoryIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="Master" />}
          {openMaster ? <ExpandLess sx={{ color: "#AA2B1D" }} /> : <ExpandMore sx={{ color: "#AA2B1D" }} />}
        </ListItem>
        <Collapse in={openMaster} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            <ListItem button component={Link} to={`/productmaster/${value.id}`} sx={{ pl: 4 }}>
              <ListItemIcon><MdProductionQuantityLimits size={22}  style={{color:"#AA2B1D"}}/></ListItemIcon>
              <ListItemText primary="Product Master" />
            </ListItem>
            <ListItem button component={Link} to={`/consigneemaster/${value.id}`} sx={{ pl: 4 }}>
              <ListItemIcon><FaHandshake  size={22}  style={{color:"#AA2B1D"}} /></ListItemIcon>
              <ListItemText primary="Consignee Master" />
            </ListItem>
          </List>
        </Collapse>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />

        {/* Other Sidebar Items */}
        <ListItem button component={Link} to={`/form/admin/${value.id}`}>
          <ListItemIcon><DescriptionIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="Generate LR" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />

        <ListItem button component={Link} to="/userlist">
          <ListItemIcon><ManageAccountsIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="User Management" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />

        <ListItem button component={Link} to="/profile">
          <ListItemIcon><AccountBoxIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="View Profile" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />

        <ListItem button component={Link} to="/">
          <ListItemIcon><ExitToAppIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="Logout" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />

        {/* Download Button */}
        <ListItem button onClick={submit}>
          <ListItemIcon><DownloadForOfflineIcon sx={{ color: "#AA2B1D" }} /></ListItemIcon>
          {drawerOpen && <ListItemText primary="Download" />}
        </ListItem>
        <Divider sx={{ bgcolor: "black", height: "1px" }} />
      </List>
    </div>
  );
  // console.log(drawerOpen);

  useEffect(() => {
    const savedInfo = localStorage.getItem("info");
    if (savedInfo) {
      const parsedInfo = JSON.parse(savedInfo);
      setValue(parsedInfo);
    }
    else {
      navigate("/");
    }

  }, []);
  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />


      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerOpen ? drawerWidth : 0}px)` },
          ml: { sm: `${drawerOpen ? drawerWidth : 0}px` },
          transition: "width 0.3s, ml 0.3s",
        }}

        style={{ backgroundColor: "white", color: "black", height: "120px" }}

      >

        {/* <Typography.Title
          level={2}
          style={{
            backgroundColor: "#AA2B1D",
            color: "white",
            height: "60px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
          }}
        >
       <b>{value.id}</b>
        </Typography.Title> */}

        <Typography variant="h3" align="center" style={{ marginTop: "15px" }}><b>{value.id}</b></Typography>
        <Typography variant="h5" align="center">{value.address}</Typography>


      </AppBar>

      <Box
        component="nav"
        sx={{
          width: { sm: drawerWidth },
          flexShrink: { sm: 0 },
          transition: "width 0.3s",
        }}
        aria-label="mailbox folders"
      >

        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerOpen ? drawerWidth : 80,
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 1, // Ensure no padding
          width: { sm: `calc(100% - ${drawerOpen ? drawerWidth : 0}px)` },
          transition: "width 0.3s",
          // ml: { sm: `${drawerOpen ? drawerWidth : 0}px` },
        }}
      >
        <Toolbar />
        {children}
      </Box>
    </Box>
  );
};

export default Sidebar;
